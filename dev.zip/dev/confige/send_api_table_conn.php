<?php
$servername = "api.cjym2crfj1fu.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$dbname45 = "heptera-api-send-table";

$send_api_table_conn = mysqli_connect($servername, $username, $password,$dbname45);



?>
