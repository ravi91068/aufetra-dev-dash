<?php
$servername = "api.cjym2crfj1fu.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$dbname45 = "heptera-api";

$heptera_api_conn = mysqli_connect($servername, $username, $password,$dbname45);



?>
