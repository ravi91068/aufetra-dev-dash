let suggestions = [
    {name:"list_name:",extra:"name of list"},
    {name:"email:",extra:"email in list"},
    {name:"content:",extra:"API template name"},
    {name:"tag:",extra:"tag of contact"},
    {name:"status:",extra:"sending status"}
];
