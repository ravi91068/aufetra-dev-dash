



<?php
session_start();
$id=$_SESSION['id'];
    $mail=$_SESSION["email"];
    

$url_main="auftera.com";


?>
<!DOCTYPE html>
<html lang="en">
<meta http-equiv="content-type" content="text/javascript; charset=UTF-8">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

<link rel="stylesheet" type="text/css" href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1628745601/loader_ww3kdih.css">


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
 
<link href='https://fonts.googleapis.com/css?family=Karla:700' rel='stylesheet' type='text/css'>
<!-- Latest compiled JavaScript -->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,100;0,300;0,400;0,700;0,900;1,100;1,300;1,400;1,700;1,900&display=swap" rel="stylesheet">

<link href="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1601356785/font-owsome/all_epmuwn.css" rel="stylesheet"> 
<style>

@import url(https://fonts.googleapis.com/css?family=Josefin+Sans);
@import url(https://fonts.googleapis.com/css?family=Arvo);
.tablediv{
    padding:10%;
}

.temp_con {
    padding: 20px;
    width: fit-content;
    border-radius: 20px;
    border: 1px solid rgb(0 0 0 / 18%);
    margin-bottom: 20px;
    background: white;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
  }

  .temp_img_con{

    border-radius: 10px;
    margin-bottom: 20px;
  }
.temp_con:hover{
    cursor:pointer;
    
}
.row{
margin-left:0px !important;
margin-right:0px !important;
}
.temp_name_sty{
padding-top: 20px;
width:180px;;
    color: #341161;
    font-family: 'Nunito Sans','Avenir Next','Segoe UI','Open Sans','Helvetica Neue',Helvetica,Arial,sans-serif;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-size: 17px;
    font-weight: 540;
    letter-spacing: 0.8px;
}
.btn-my:hover{
    outline:2px solid;
    cursor:pointer;

}
.card:hover{
    cursor:default;
}
.btn-my{
    height:50px;text-align:center;background:#f2f2f2;border:none;
    
}
.btn-my:active{
    border:2px solid;
}
.btn-my:focus{
    border:2px solid;
}




.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}




.nav-link:hover{
    cursor:pointer;
}
.sticky {

  position: fixed;
  top: 0;
  width: 100%;
  z-index: 10;
}
.lablecon{
    padding:40px;
    max-width:70%;
}
.submiturl:hover{
    border:2px solid;
} 
ul{
    list-style:none;
}
.stepst3{
    font-size:30px;
    display: inline-block;
    width: auto;
    height: auto;
    margin: 6px;
    
}


.modal-input:focus{

outline: none;
    border: 1px solid #007c89;
    box-shadow: inset 0 0 0 2px #007c89;

}



.addsiteheadbtn:hover{
    color:black;
    cursor:pointer;
    background:#d9d7cd;

}

#loader {
  position: absolute;
  left: 50%;
  top: 50%;
  z-index: 1;
  width: 150px;
  height: 150px;
  margin: -75px 0 0 -75px;
  border: 5px solid #f3f3f3;
  border-radius: 50%;
  border-top: 5px solid black;
  width: 40px;
  height: 40px;
  -webkit-animation: spin .5s linear infinite;
  animation: spin .5s linear infinite;
}

@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.nav-link{
    padding:20px !important;
    transition: color .1s cubic-bezier(.4,0,.2,1);
}
.bottom-btn{
  text-align: center;
    height: 40px;
    background: #104b7b;
    color: white;
    font-weight: 800;
    font-size: 15px;
    border-radius: 4px;
    border: none;
    float: right;
    padding-left: 20px;
    padding-right: 20px;
}
.bottom-btn:hover{
	cursor: pointer;
}

.bottom-btn:focus{
  outline: none !important;
}
.bottom-btn:active{
  outline: none !important;
}




.res_of_hepta {
    padding: 10px;
    background: #0700ff1f;
    color: black;
    font-weight: 600;
    border-radius: 5px;
    border: 4px solid #0008ff4f;
display:none;


}



.not-fd-data{
  text-align: center;
padding: 40px;
    background: white;
    border-radius: 4px;

}




.txt-not-fd{
  padding-top: 20px;
    padding-bottom: 20px;
    width: 500px;
    margin: 0px auto;
    font-weight: 600;
    color: #080808cf;
}

body{
  font-family: 'lato';
}

.note-editable {
    line-height: 2;
}

.nav-link{
  color: #525f7f;
  font-size: 14px;
    font-weight: 500 !important;
}

.card{
  height: min-content;
  width: 30rem;
  border: none;

  padding: 0px;
  border-radius: 20px;
  box-shadow: rgba(50, 50, 93, 0.25) 0px 2px 5px -1px, rgba(0, 0, 0, 0.3) 0px 1px 3px -1px;
}

.head-cons-desg{
  padding: 50px 0px;
}

.card-img-top{
height: 200px;
    padding: 40px;
border-top-left-radius: 20px;
    border-top-right-radius: 20px;

}

.card-body{
  text-align: center;
}

.card-text{
  font-weight: 500;
  color: black;
  font-family: 'lato';
}

.card-title {
    margin-bottom: 1.25rem;
    font-size: 20px;
color: black;

    }

    a.crt-api-btn {
    color: #3368fa;
    background-color: #fff;
    border-color: #3368fa;
    font-family: Colfax-Bold,Helvetica,Arial,sans-serif;
    font-style: normal;
    font-weight: 600;
    display: inline-block;
    padding: 12px 32px;
    font-size: 16px;
    line-height: normal;
    text-align: center;
    border: 2px solid transparent;
    border-radius: 3px;
    outline: 0;
    box-shadow: 0 2px 4px 0 #c8d7ee;
    transition: all .2s ease-in-out;
    border: 2px solid;

  }



</style>


<style type="text/css">



.pdfobject-container {
  height: 30rem;
  border: 1rem solid rgba(0, 0, 0, 0.1);
}

.trigger {
  margin: 0 0.75rem;
  padding: 0.625rem 1.25rem;
  border: none;
  border-radius: 0.25rem;
  box-shadow: 0 0.0625rem 0.1875rem rgba(0, 0, 0, 0.12), 0 0.0625rem 0.125rem rgba(0, 0, 0, 0.24);
  transition: all 0.25s cubic-bezier(0.25, 0.8, 0.25, 1);
  font-size: 0.875rem;
  font-weight: 300;
}
.trigger i {
  margin-right: 0.3125rem;
}
.trigger:hover {
  
}


.main-content{
  



}

.main-content::-webkit-scrollbar {
  display: none;
}

/* Hide scrollbar for IE, Edge and Firefox */
.main-content {
  -ms-overflow-style: none;  /* IE and Edge */
  scrollbar-width: none;  /* Firefox */
}

.del-send-api-temp:hover {
    color: deeppink;
  }

  .not-fd-temp-api-data {
    width: 100%;
    text-align: center;
    padding: 20px;
    border: 1px solid rgb(0 0 0 / 18%);
    border-radius: 5px;
  }


  .suc_ret_dt {
    text-align: center;
    font-size: 40px;
    padding-top: 20px;
    color: midnightblue;

  }

  .rate-wrt_dt {
    width: 100px;
    margin: auto;
    height: 100px;
    padding: 20px;
    border-radius: 50%;
    border: 1px solid green;
    color: black !important;


  }

.rate-wrt_dt h2{

  color: midnightblue;
  font-size: 20px;
}

sub{
  font-size: 10px;
}

.wrapper {
    width: fit-content;
    }

table {
  border-spacing: 1;
  border-collapse: collapse;
  background: white;
  border-radius: 6px;
  overflow: hidden;
  max-width: 90%;
  width: 100%;
  margin: 0 auto;
  position: relative;
}
table * {
  position: relative;
}
table td, table th {
  padding-left: 8px;
  font-weight: 500;
}
table thead tr {
 
    color: midnightblue !important;

  height: 60px;
  
  font-size: 16px;
}
table tbody tr {
  height: 48px;
  border-bottom: 1px solid #E3F1D5;
  color: black;
  background: #f2f2f2ab;
}
table tbody tr:last-child {
  border: 0;
}
table td, table th {
  text-align: left;
}
table td.l, table th.l {
  text-align: right;
}
table td.c, table th.c {
  text-align: center;
}
table td.r, table th.r {
  text-align: center;
}

@media screen and (max-width: 35.5em) {
  table {
    display: block;
  }
  table > *, table tr, table td, table th {
    display: block;
  }
  table thead {
    display: none;
  }
  table tbody tr {
    height: auto;
    padding: 8px 0;
    color: #2d2222f7;
    font-weight: 200 !important;
  }
  table tbody tr td {
    padding-left: 45%;
    margin-bottom: 12px;
  }
  table tbody tr td:last-child {
    margin-bottom: 0;
  }
  table tbody tr td:before {
    position: absolute;
    font-weight: 700;
    width: 40%;
    left: 10px;
    top: 0;
  }
  table tbody tr td:nth-child(1):before {
    content: "Code";
  }
  table tbody tr td:nth-child(2):before {
    content: "Stock";
  }
  table tbody tr td:nth-child(3):before {
    content: "Cap";
  }
  table tbody tr td:nth-child(4):before {
    content: "Inch";
  }
  table tbody tr td:nth-child(5):before {
    content: "Box Type";
  }
}

div#send_api_history {
    padding-bottom: 100px;
  }










.wrapper{
  margin-left: auto;
}


.wrapper .search_box {
    width: 500px;
    color: black;
    background: #fff;
    border-radius: 5px;
    display: flex;
    height: 51px;
    padding: 3px;
    box-shadow: 0 8px 6px -10px #b3c6ff;
    border: 1px solid rgb(0 0 0 / 18%);

  }

.wrapper .search_box .dropdown-sel {
    width: 150px;
    border-right: 1px solid rgb(0 0 0 / 18%);
    position: relative;
    cursor: pointer;
    color: #4a154bd9;
    font-weight: 600;
  }

.wrapper .search_box .dropdown-sel .default_option{
  text-transform: uppercase;
  padding: 13px 15px;
  font-size: 14px;
}

.wrapper .search_box .dropdown-sel ul{
  position: absolute;
 
  background: #fff;
  width: 150px;
  border-radius: 5px;
  padding: 20px;
  display: none;
  border: 1px solid rgb(0 0 0 / 18%);
  z-index: 1;
    margin-top: 10px;
}

.wrapper .search_box .dropdown-sel ul.active{
  display: block;
}

.wrapper .search_box .dropdown-sel ul li{
  font-size: 13px;
  padding-bottom: 10px;
}

.wrapper .search_box .dropdown-sel ul li:last-child{
  padding-bottom: 0;
}

.wrapper .search_box .dropdown-sel ul li:hover{
  color: #6f768d;
}



.wrapper .search_box .search_field{
  width: 350px;
  height: 100%;
  position: relative;
}

.wrapper .search_box .search_field .input{
  width: 100%;
  height: 100%;
  border: 0px;
  font-size: 16px;
  padding-left: 20px;
  padding-right: 38px;
  color: #6f768d;
}

.wrapper .search_box .search_field .fad{
  position: absolute;
  top: 10px;
  right: 10px;
  font-size: 22px;
  color: #4a154bd9;
  cursor: pointer;
}

::-webkit-input-placeholder { /* Chrome/Opera/Safari */
  color: #9fa3b1;
}
::-moz-placeholder { /* Firefox 19+ */
 color: #9fa3b1;
}
:-ms-input-placeholder { /* IE 10+ */
  color: #9fa3b1;
}

input{
  border: none;
  outline: none;
}
i.fad.fa-chevron-down {
    margin-left: auto;
    float: right;
    font-size: 16px;
    color: #4a154bd9;
  }





.lds-color div{

border: 2px solid #4a154bd9 !important;border-color: #4a154bd9 transparent transparent transparent !important;

}


.lds-pos-cht{

  top: 50%;
  left: 50%;
}

.lds-pos-bg{
top: 50%;

}

.lds-ring {
  display: inline-block;
  position: relative;
  width: 16px;
  height: 16px;
  margin:4px;
}
.lds-ring div {
  box-sizing: border-box;
  display: block;
  position: absolute;
  width: 16px;
  height: 16px;
 
  border: 2px solid white;
  border-radius: 50%;
  animation: lds-ring 1.2s cubic-bezier(0.5, 0, 0.5, 1) infinite;
  border-color: white transparent transparent transparent;
}
.lds-ring div:nth-child(1) {
  animation-delay: -0.45s;
}
.lds-ring div:nth-child(2) {
  animation-delay: -0.3s;
}
.lds-ring div:nth-child(3) {
  animation-delay: -0.15s;
}
@keyframes lds-ring {
  0% {
    transform: rotate(0deg);
  }
  100% {
    transform: rotate(360deg);
  }
}





.navbar-dark .navbar-nav .nav-link {
    color: #4a154b;
    font-size: 13px;
    font-weight: 600;

}


.navbar-dark .navbar-nav .nav-link:hover{

color:#4a154b;

}




.dis-non-crd-dt{

display:none;
}



.sd-con-ico.dsc-inln-flx {
    width: 8%;
    height: 100%;
}

.tooltip-arrow {
    
    }


[data-popper-placement="right"]>.tooltip-arrow{

transform: none !important;
    top: 8px !important;

}
.main-con-of-crm.dsc-inln-flx {
    width: 92%;
    height: 100vh;
    float: right;
    background: #fafafa;
    overflow: scroll;
}

    .dsc-inln-flx {
    display: inline-block;
}

.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

    .icon-con-of-sd {
    height: 90vh;
    width: 100%;
}

.icon-main-con {
    height: auto;
    width: 100%;
    position: relative;
    top: 50%;
    -ms-transform: translateY(-50%);
    transform: translateY(-50%);
    }

    .con-ico {
    padding: 20px;
    text-align: center;
}

img.con-of-ico-img {
    height: 30px;
    }




.con-of-main-splt {
    width: 20%;
    height: 100vh;
    display: inline-block;

}
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }

   
h2.head-od-dt-shw {
    margin: 0px;
    }


button.btn-of-drk-back {
    height: 6vh;
    width: 100%;
    background: #125ef6;
    border: 0px;
    border-radius: 5px;
    color: white;
}

.con-of-dt-sel-ele {
    height: 80vh;
    width: 100%;
    overflow: scroll;
    }

    .container-2GnNH {
    display: -webkit-box;
    display: -ms-flexbox;
    display: flex;
    -webkit-box-orient: horizontal;
    -webkit-box-direction: normal;
    -ms-flex-direction: row;
    flex-direction: row;
    -webkit-box-align: center;
    -ms-flex-align: center;
    align-items: center;
    padding: 15px;
}
a.com-for-lnk {
    text-decoration: none;
    color: black;
    }

    h2.head-od-dt-shw {
    margin: 0px;
    font-family: lato;
    font-size: 15px;
    font-weight: bolder;
}
.con-of-main-splt {
    width: 20%;
    height: 100vh;
    background: #e5eafc30;
    }


    .eml-add-main-con {
    width: 29%;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    font-size: 16px;
    
}


th {
    font-size: 14px;
    font-weight: 400;
    padding: 15px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07);
    color: rgb(120 120 150);
    font-family: 'Lato';
  }

  td {
    padding: 20px 10px;
    font-size: 13px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.07);
    background: white;
  }

  table#data-tbl-name {
    width: 100%;
    background-color: rgb(255, 255, 255);
    border-radius: 8px;
    box-shadow: rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 8%) 0px 2px 4px;
  }
.sd-hd-con {
    height: 10vh;
    text-align: center;
    }
    input.srch-ip-fld {
    width: 100%;
    height: 3vh;
    border: none;
    font-family: 'Lato';
    font-weight: 500;
    color: #c7ccd7;
}
.con-of-full-email-dt {
    width: 100%;
    height: 90vh;
    }

    .img-eml-ico-con {
    font-family: 'Lato';
    padding: 15px;
    border-radius: 50%;
    background: pink;
    margin-right: 10px;
    color: #ca1938;
}
.sub-ln-of-email-txt {
    width: 240px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
    font-family: 'Lato';
    color: #908c8c;
    font-size: 13px;
}
input.srch-ip-fld:focus{
    outline: none;
    border: none;
}

    .fnt-ico-sel {
    width: 20px;
    text-align: center;
}


div#confirm_arch_all {
    z-index: 10000000;
}
.con-of-cht-usr {
    width: 50%;
    display: inline-block;
    height: 100vh;
    display: inline-block;
    vertical-align: top;
    margin: 0;
    padding: 0;
    border-left: 1px solid #f2f2f2;
    }





.con-ico:hover{
    cursor: pointer;
}

.head-of-dash{
    background: #4a154b;
    text-align: right;
    border-bottom-left-radius: 50px;
}


.dropdown-menu .dropdown-item {
    padding: .5rem 1rem;
    font-size: 13px;
    font-weight: 600;
}

button.dropdown-item.comm_up_btn:hover {
    background: #0d66d6;
    color: white;
    }

    .dropdown-header {
    padding: .5rem 1rem;
    color: #f6f9fc;
    font-size: .625rem;
    text-transform: uppercase;
    font-weight: 700;
}
.dropdown-header {
    display: block;
    padding: .5rem 1rem;
    margin-bottom: 0;
    font-size: 0.875rem;
    color: #8898aa;
    white-space: nowrap;
    }
    .dropdown-menu {
    padding: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px !important;
}

.dropdown-item {
    border-radius: 10px;
    }

h6, .h6 {
    font-size: 0.625rem !important;
}


.head-of-inn-con {
    padding: 24px 0px;
    width: fit-content;
}
.all-auta-con {
    padding: 0px 24px;
    }
    span.nm-auta-con {
    font-size: 16px;
    font-weight: 500;
    font-family: 'lato';
    color: #00000080;
}

.crt-new-auta-con {
    width: 200px;
    background: rgb(143 4 175);
    padding: 24px 16px;
    border-radius: 10px;
    height: 200px;
    margin-right: 30px;
    margin-top: 20px;
   
    margin-left: 20px;
}

    .new-crt-head {
    line-height: 28px;
    font-weight: 700;
    color: white;
    font-family: 'Lato';
}
.con-of-crt-new-img {
    text-align: center;
    width: min-content;
    margin-top: 60px;
    padding: 10px;
    margin-left: auto;
    margin-right: auto;
    border-radius: 50%;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
    }

    .crt-new-auta-con:hover{
cursor: pointer;
    }

   .auta-dis-on-dash {
    width: 200px;
    padding: 24px 16px;
    border-radius: 10px;
    background: white;
    margin-right: 30px;
    height: 200px;
    padding-bottom: 0px;
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px;
    
    margin-top: 20px;
   margin-left: 20px;    
}

.auta-dis-on-dash:hover{
    box-shadow: rgb(0 0 0 / 8%) 0px 2px 4px, rgb(0 0 0 / 6%) 0px 2px 12px, rgb(0 0 0 / 4%) 0px 8px 14px, rgb(0 0 0 / 2%) 0px 12px 16px;
cursor: pointer;

}
.main-con-name {
    flex: auto;
    min-height: 116px;
    display: inline-grid;
    width: 100%;
}
    
    span.bdg-tp-btn {
    margin-left: auto;
    font-size: 12px;
    background: rgb(245, 249, 248);
    padding: 2px 10px;
    border-radius: 10px;
    color: rgb(2, 80, 65);
    font-family: 'Lato';
    font-weight: 600;
    letter-spacing: .4px;
    height: fit-content;
}
.def-name-con-crd {
    display: inline-flex;

}
.ico-of-act-lst {
    width: 40%;
    margin: auto;
    text-align: center;
    padding: 10px;
    width: fit-content;
    border-radius: 10px;
    background: #f2f2f2;
    transition:.4s;
    }

    img.ico-img-src {
    height: 25px;
}
    .def_stat-of-dt {
    padding: 16px 0px;
    display: inline-flex;
    width: 100%;
    height: 60px;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    
}
    .con-of-cnt-data {
    padding: 5.5px 10px;
    background: rgba(0, 0, 0, 0.07);
    border-radius: 5px;
    color: rgb(38, 38, 39);
    width: 60%;
    text-align: center;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
}
.def_stat-of-dt > div {
    font-size: 14px;
    height: fit-content;
    }

    .con-of-dp-data {
    width: 40%;
}

button#dropdownMenuButton {
    background: no-repeat;
    border: none;
    height: 32px;
    padding: 5.5px;
    float: right;
    }

.all-auta-con {
    padding: 0px 24px;
    display: inline-flex;

}
.dropdown-toggle::after{
    display: none;
}

.dropdown-menu.show{
    border: none;
    border-radius: 10px;
}

a.com-for-lnk {
    text-decoration: none;
    color: #00000091;
    }
    .marg-for-temp{
        margin-left: 0px;
        margin-right: 30px;
    }
    .img-temp-of-mark{
        width: 168px;
        height: 166px;
    }










  .ip-by-def-dsg {
    width: 100%;
    background-color: #FFFFFF;
    height: 48px;
    padding-left: 16px;
    padding-right: 16px;
    border-radius: 4px;
    margin: 8px 0px;
    border: 1px solid #B8B8B8;
    font-weight: 400;
    font-size: 14px;
    text-align: left;
    box-sizing: border-box;
    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;
    box-shadow: 2px 2px 0 2px transparent;
    text-overflow: ellipsis;
    overflow: hidden;


  }

  .ip-by-def-dsg:focus {
    background-color: #fff;
    outline: 0;
    border-color: #524d52;
    box-shadow: 0 0 0 3px #bdb2bd4d;

    -webkit-transition-property: border-width,border-color,box-shadow;
    transition-property: border-width,border-color,box-shadow;
    -webkit-transition-duration: 0.1s;
    transition-duration: 0.1s;
    -webkit-transition-timing-function: ease-in;
    transition-timing-function: ease-in;

  }



button:disabled,
button[disabled]{
  border: 1px solid #999999;
  background-color: #cccccc;
  color: #666666;
  border: none;
  cursor: not-allowed;
}

.btn-blck-in-auta-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(38, 38, 39);
    color: rgb(255, 255, 255);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
    font-family: 'lato';
}

.btn-blck-in-auta-fcs:hover{
    background-color: rgb(71, 71, 71);
    transition: all 0.2s ease 0s;
}

.btn-blck-non-fcs{
    display: inline-flex;
    -webkit-box-align: center;
    align-items: center;
    -webkit-box-pack: center;
    justify-content: center;
    background-color: rgb(227, 227, 227);
    color: rgb(38, 38, 39);
    position: relative;
    outline: none;
    font-family: inherit;
    border: 0px;
    transition: all 0.4s ease 0s;
    cursor: pointer;
    white-space: nowrap;
    text-decoration: none;
    border-radius: 4px;
    padding: 6px 12px;
    min-height: 32px;
    font-size: 14px;
    line-height: 20px;
}

.btn-blck-non-fcs:hover{
    background-color: rgb(231, 231, 231);
    transition: all 0.2s ease 0s;
    color: black;
}

.modal-content{
    border-radius: 8px;
}

.btn-blck-non-fcs:focus{
    color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;
}
.btn-blck-non-fcs:active{

color: #fff;
    background-color: #313335 !important;
    border-color: #3d3e40 !important;
    box-shadow: 0 0 0 0.2rem rgb(68 70 72 / 50%) !important;

}


.con-of-temp-lst {
    display: inline-flex;
    width: 100%;
    padding: 5px 10px;
    border-radius: 10px;
    margin-bottom: 10px;
    }

    .con-of-temp-lst:hover {
    background: #f2f2f28a;
    cursor: pointer;
}

.con-of-temp-lst>div {
    width: 50%;
    }

    span.temp-name {
    font-size: 14px;
}

span.crt-data-of-tmp {
    font-size: 10px;
    }
.row{
    margin-left: 0px;
    margin-right: 0px;
}








.btn-primary.focus, .btn-primary:focus{

    color: #fff;
    box-shadow: 0 0 0 0.2rem rgb(105 109 113 / 50%);
    background-color: rgb(38, 38, 39);
    border-color: rgb(38, 38, 39);

}





.err-menu-cls-dsg{

transition:.2s;
  top: auto !important;
    width: fit-content;
    bottom: 10vh !important;
    padding: 10px;
    background: #000000e8;
    font-size: 13px;
    border-radius: 5px;
    z-index: 100;
    color: white !important;
    display: none;
    z-index: 100000000;
}

#cncl-err-msg:hover{


cursor: pointer;


}



.vert-cent-div {
 
  height: min-content;
  text-align: center;
  
  position: absolute;
  top:0;
  bottom: 0;
  left: 0;
  right: 0;
    
  margin: auto;
}

.switch-dis{
    display: none;
}






button:disabled,
button[disabled]{
  
  background-color: #cccccc !important;
  color: #666666 !important;
  border: none;
  cursor: not-allowed;
}



.data-head-of-img-fold {
    margin-top: 20px;
    display: inline-flex;
    width: 100%;
    margin-bottom: 20px;
    }

    .main-con-of-img-con {
    width: 100%;
    height: calc(100vh - 8vh - 76px);
    overflow: scroll;
    padding: 30px;
}

.back-btn-to-fold {
    padding: 10px;
    background: #ff008a;
    border-radius: 100px;
    font-size: 12px;
    color: white;
    font-weight: 700;
    margin-left: auto;
    margin-right: auto;
    }

    .con-of-srch-img {
    width: 50%;
}

.con-of-act-img {
    display: inline-flex;
    width: 30%;
    }

    .back-btn-to-fold.color-of-opt-btn {
    padding: 6px;
    background: #c3c2c2;
    border: 0px;
    transition: .4s;
}

.auta-dis-on-dash.img-con-of-fold {
    position: relative;
    padding: 0px;
    border-radius: 0px;
    display: flex;
    justify-content: center;
    margin-right: auto;
    margin-left: 20px;
}
   img.img-tag-for-con {
    width: auto;
    height: auto;
    position: absolute;
    top: 0;
    bottom: 0;
    max-height: 100%;
    max-width: 100%;
    margin: auto;
}

.back-btn-to-fold.color-of-opt-btn:hover {
    cursor: pointer;
    background: #c3c2c28f;
    }
    button.back-btn-to-fold.color-of-opt-btn:focus {
    outline: none;
}

.main-con-of-img-con{
    display: inline-flex;
}

.btn-mdl-act-sel {
    border-radius: 100px !important;
    color: black;
    font-weight: 500;
    font-size: 12px;
    margin-top: 20px;
    text-align: left;
    width: fit-content;
    }

    .btn-mdl-act-sel.active >svg {
    fill: white;
}

.btn-mdl-act-sel >svg {
    fill: black;
    }

    .btn-mdl-act-sel>svg{
        margin-right: 10px;
    }

    .btn-mdl-act-sel:hover svg{
        fill:blue;
    }

    .btn-mdl-act-sel.active:hover svg{
        fill:white;
    }

    .midd-sel-img {
    padding: 40px;
    border: 1px dashed;
    width: fit-content;
    padding: 40px;
    height: 100px;
    
    border-radius: 10px;

}

.midd-sel-img:hover{
    cursor: pointer;
}

img.img-pre-tg-img {
    width: 100%;
    height: auto;
    max-height: 100px;
    border-radius: 10px;

    }

    .img-con-pre {
    width: 98px;
    margin-right: 0px;
    height: 100px;
    position: relative;
    margin-right: 10px;
    margin-top: 10px;
}

#upload_img_form{
    display: inline-flex;
}

.con-of-all-srch {
    width: 600px;
    }

    .con-of-srch-img-thumb {
    border-top-right-radius: 10px;
}

img.img-of-con-srch {
    height: 200px;
    max-width: 250px;
    }

    .btn-con-of-dwn {
    padding: 10px;
    text-align: center;
}

    .full-swn-btn {
    width: fit-content;
    margin-right: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    margin-top: 10px;
    padding: 0px;
    border-radius: 10px;
}

.active_img_act {
    border: 3px solid blue;
    box-shadow: rgb(0 0 0 / 25%) 0px 14px 28px, rgb(0 0 0 / 22%) 0px 10px 10px;
    }

button.close {
    background: no-repeat;
    border: none;
    }


    th {
    font-weight: 600;
    font-size: 13px;
}

td {
    font-size: 12px;
    }


    .cp-round:after{
        border-top: solid 3px #564f4e;


    }
.img_editor-con{
    display: none;
}

    .tui-image-editor-header{
        display: none;
    }

    #tui-image-editor-container {
    width: 100% !important;
    height: calc(100vh - 52px) !important;
    top: 0px;
    position: fixed;
}

.save-fl-bar-con {
    width: 100%;
    height: 52px;
    background: #171717;
    margin-top: calc(100vh - 52px) !important;
    padding: 10px;
    text-align: right;
    }

    .ico-of-act-lst:hover{
        background:black !important;
    }


</style>

<head>
  <meta charset="utf-8" />
  
  <title>
    Dashboard of heptera mail
  </title>
  <!-- Favicon -->
  
  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700" rel="stylesheet">
  <!-- Icons -->
  

 
  <!-- CSS Files -->
 
</head>
<div id="c"></div>
<body class="" style="">
 



  <div class="main-con-of-dash">

    <div class="sd-con-ico dsc-inln-flx" style="
">
    
    <div class="sd-hd-con"><img src="https://res.cloudinary.com/heptera/image/upload/v1611850905/landing/open-collective_1_m4opwf.svg" width="" style="
    padding: 2vh
    ">
</div>

<div class="icon-con-of-sd">

    <style>


#main-loader-containre-act{


    text-align: center;
    padding-top: 41vh;
  }

.main-loader-containre-act{
  text-align: center;padding-top: 41vh;height: 84vh;
}



</style>
<div class="icon-main-con">
<div class="con-ico com-for-lnk" data-for-serv="0" data-target-link="https://campign.auftera.com/campigns/all-campign" data-toggle="tooltip" data-placement="right" title="Sheduled Campigns"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278281/automation/schedule_send_black_24dp_wybxtb.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/#acl" data-toggle="tooltip" data-placement="right" title="Manage Contact List"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1628748461/email-crm/playlist_add_circle_black_24dp_eryixo.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="template/" data-target-link="https://template.auftera.com/template/" data-toggle="tooltip" data-placement="right" title="Manage Template"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278301/automation/web_black_24dp_kx5cze.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="studio/" data-target-link="https://studio.auftera.com/studio/" data-toggle="tooltip" data-placement="right" title="Browse Studio"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1626278284/automation/camera_black_24dp_ldwdgu.svg"></div>
<div class="con-ico" data-toggle="tooltip" data-placement="right" title="Launch Automation"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1627707060/automation/model_training_black_24dp_wjuu9i.svg"></div>
<div class="con-ico com-for-lnk" data-for-serv="1" data-path-ses="social/" data-target-link="https://social.auftera.com/social/" data-toggle="tooltip" data-placement="right" title="Social Post"><img class="con-of-ico-img" src="https://res.cloudinary.com/heptera/image/upload/v1627537307/automation/share_black_24dp_wpgnni.svg"></div>
</div>
<script>


id='<?php echo $id;?>';
email='<?php echo $email;?>';

$(document).on('click','.com-for-lnk',function(){



$("#main-loader-containre").addClass("main-loader-containre-act");
$("#main-loader-containre").html('<div class="cp-spinner cp-round"></div>');

url_lnk=$(this).attr('data-target-link');
ses_path=$(this).attr('data-path-ses');


var sourceString = url_lnk.replace('http://','').replace('https://','').replace('www.','').split(/[/?#]/)[0];

if($(this).attr('data-for-serv')=='1'){

red_url="https://"+sourceString+"/"+ses_path+"confige/crt_ses.php?id="+id+"&email="+email+"&url_red="+url_lnk;

console.log(red_url);


}else if($(this).attr('data-for-serv')=='0'){



red_url=$(this).attr('data-target-link');





}

console.log(red_url);
window.location.href=red_url;


})
</script>


</div>
        
    
    </div>

     <div class="main-con-of-crm dsc-inln-flx">


      <div class='head-of-dash' >







<div class="dropdown" style="
    height: 8vh;
"> 
    <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="
    height: 8vh;
"> 
       <svg width="30" height="30" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" style="color:white;"><path d="M7 7H9V9H7V7Z" fill="currentColor"></path><path d="M11 7H13V9H11V7Z" fill="currentColor"></path><path d="M17 7H15V9H17V7Z" fill="currentColor"></path><path d="M7 11H9V13H7V11Z" fill="currentColor"></path><path d="M13 11H11V13H13V11Z" fill="currentColor"></path><path d="M15 11H17V13H15V11Z" fill="currentColor"></path><path d="M9 15H7V17H9V15Z" fill="currentColor"></path><path d="M11 15H13V17H11V15Z" fill="currentColor"></path><path d="M17 15H15V17H17V15Z" fill="currentColor"></path></svg>
    </button> 
    <div class="dropdown-menu dropdown-menu-right" x-placement="bottom-end" style="position: absolute; transform: translate3d(905px, 53px, 0px); top: 0px; left: 0px; will-change: transform;">
<div class=" dropdown-header noti-title">
<h6 class="text-overflow m-0">admin@auftera.com</h6>
</div>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/sites/add_sites/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 8C6.74028 8 7.38663 7.5978 7.73244 7H14C15.1046 7 16 7.89543 16 9C16 10.1046 15.1046 11 14 11H10C7.79086 11 6 12.7909 6 15C6 17.2091 7.79086 19 10 19H16.2676C16.6134 19.5978 17.2597 20 18 20C19.1046 20 20 19.1046 20 18C20 16.8954 19.1046 16 18 16C17.2597 16 16.6134 16.4022 16.2676 17H10C8.89543 17 8 16.1046 8 15C8 13.8954 8.89543 13 10 13H14C16.2091 13 18 11.2091 18 9C18 6.79086 16.2091 5 14 5H7.73244C7.38663 4.4022 6.74028 4 6 4C4.89543 4 4 4.89543 4 6C4 7.10457 4.89543 8 6 8Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Connected App </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/sender/add_sender/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M16 9C16 11.2091 14.2091 13 12 13C9.79086 13 8 11.2091 8 9C8 6.79086 9.79086 5 12 5C14.2091 5 16 6.79086 16 9ZM14 9C14 10.1046 13.1046 11 12 11C10.8954 11 10 10.1046 10 9C10 7.89543 10.8954 7 12 7C13.1046 7 14 7.89543 14 9Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M12 1C5.92487 1 1 5.92487 1 12C1 18.0751 5.92487 23 12 23C18.0751 23 23 18.0751 23 12C23 5.92487 18.0751 1 12 1ZM3 12C3 14.0902 3.71255 16.014 4.90798 17.5417C6.55245 15.3889 9.14627 14 12.0645 14C14.9448 14 17.5092 15.3531 19.1565 17.4583C20.313 15.9443 21 14.0524 21 12C21 7.02944 16.9706 3 12 3C7.02944 3 3 7.02944 3 12ZM12 21C9.84977 21 7.87565 20.2459 6.32767 18.9878C7.59352 17.1812 9.69106 16 12.0645 16C14.4084 16 16.4833 17.1521 17.7538 18.9209C16.1939 20.2191 14.1881 21 12 21Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Sender Profile</span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="account/" data-target-link="https://account.auftera.com/account/smtp/add_smtp/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M9 6C8.44772 6 8 6.44772 8 7C8 7.55228 8.44772 8 9 8H15C15.5523 8 16 7.55228 16 7C16 6.44772 15.5523 6 15 6H9Z" fill="currentColor"></path><path d="M9 10C8.44772 10 8 10.4477 8 11C8 11.5523 8.44772 12 9 12H15C15.5523 12 16 11.5523 16 11C16 10.4477 15.5523 10 15 10H9Z" fill="currentColor"></path><path d="M13 17C13 17.5523 12.5523 18 12 18C11.4477 18 11 17.5523 11 17C11 16.4477 11.4477 16 12 16C12.5523 16 13 16.4477 13 17Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M4 5C4 3.34315 5.34315 2 7 2H17C18.6569 2 20 3.34315 20 5V19C20 20.6569 18.6569 22 17 22H7C5.34315 22 4 20.6569 4 19V5ZM7 4H17C17.5523 4 18 4.44772 18 5V19C18 19.5523 17.5523 20 17 20H7C6.44772 20 6 19.5523 6 19V5C6 4.44772 6.44771 4 7 4Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
SMTP Server </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="0" data-path-ses="contact/" data-target-link="https://contact.auftera.com/contact/emb/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M9 3H3V9H5V5H9V3ZM3 21V15H5V19H9V21H3ZM15 3V5H19V9H21V3H15ZM19 15H21V21H15V19H19V15ZM7 7H11V11H7V7ZM7 13H11V17H7V13ZM17 7H13V11H17V7ZM13 13H17V17H13V13Z" fill="currentColor"></path></svg><span class="padding-left:10px;">
Integration </span></button>
<button class="dropdown-item comm_up_btn com-for-lnk" data-for-serv="1" data-path-ses="dev/" data-target-link="https://dev.auftera.com/dev/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M4 14V20H10V18H6V14H4Z" fill="currentColor"></path><path fill-rule="evenodd" clip-rule="evenodd" d="M9 9V15H15V9H9ZM13 11H11V13H13V11Z" fill="currentColor"></path><path d="M4 10V4H10V6H6V10H4Z" fill="currentColor"></path><path d="M20 10V4H14V6H18V10H20Z" fill="currentColor"></path><path d="M20 14V20H14V18H18V14H20Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
API</span></button>
<div class="dropdown-divider"></div>
<button class="dropdown-item comm_up_btn" data-for-serv="1" data-target-link="http://account.auftera.com/logout/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path fill-rule="evenodd" clip-rule="evenodd" d="M11 19V22H13V19H14C16.2091 19 18 17.2091 18 15C18 12.7909 16.2091 11 14 11H13V7H15V9H17V5H13V2H11V5H10C7.79086 5 6 6.79086 6 9C6 11.2091 7.79086 13 10 13H11V17H9V15H7V19H11ZM13 17H14C15.1046 17 16 16.1046 16 15C16 13.8954 15.1046 13 14 13H13V17ZM11 11V7H10C8.89543 7 8 7.89543 8 9C8 10.1046 8.89543 11 10 11H11Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Plan</span></button>
<button class="dropdown-item comm_up_btn com" data-for-serv="1" data-target-link="http://account.auftera.com/logout/">
<svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M8.51428 20H4.51428C3.40971 20 2.51428 19.1046 2.51428 18V6C2.51428 4.89543 3.40971 4 4.51428 4H8.51428V6H4.51428V18H8.51428V20Z" fill="currentColor"></path><path d="M13.8418 17.385L15.262 15.9768L11.3428 12.0242L20.4857 12.0242C21.038 12.0242 21.4857 11.5765 21.4857 11.0242C21.4857 10.4719 21.038 10.0242 20.4857 10.0242L11.3236 10.0242L15.304 6.0774L13.8958 4.6572L7.5049 10.9941L13.8418 17.385Z" fill="currentColor"></path></svg>
<span class="padding-left:10px;">
Log Out</span></button>
</div>
 </div>









        </div>


<div class="main-content container" style="top:0px;">



 <div class="head-of-inn-con">
<span class="nm-auta-con">API Credential</span>
</div>

<div class="row">

  <div class="card" >
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1629784803/api/undraw_revenue_3osh_rvb74c.svg" alt="Card image cap" style="background: linear-gradient(
150deg
, rgb(31 19 232) 27%, rgb(15 13 113) 100%);">
  <div class="card-body">
    <h3 class="card-title">Managment API</h3>
    <p class="card-text">Management API Is used for manage contact of contact list. <b>show,delete,add</b> contact from contact list</p>
   
<div class=' ' id='acc-token-handl-1'>
    <button class="btn btn-primary btn-blck-in-auta-fcs" data-toggle="modal" data-target="#modal-mngc-api-data" data-modal-trigger="modal-mngc-api-data">Create Key</button>
  </div>
  </div>
</div>



<div class="card" style="margin-left: auto;">
  <img class="card-img-top" src="https://res.cloudinary.com/heptera/image/upload/v1629785354/api/undraw_Opened_re_i38e_yuigcx.svg" alt="Card image cap" style="background: linear-gradient(
150deg
, rgb(226 20 94) 59%, rgba(187,76,101,1) 99%);">
  <div class="card-body">
    <h3 class="card-title">Sending API</h3>
    <p class="card-text">Sending API Is used to get send automayion of your system. like <b>OTP,transactonal message or create campign</b> from your automated system.</p>
   <div class=' ' id='acc-token-handl-2'>
    <button class="btn btn-primary btn-blck-in-auta-fcs" data-toggle='modal' data-target='#modal-send-api-data' >Create Key</button>
  </div>
  </div>
</div>


</div>


<div class='suc_api-hand-rat-fl-bx dis-non-crd-dt'>


<div class="head-of-inn-con">
<span class="nm-auta-con">API Used Attemp</span>
</div>

<div id='success_rate_data' class='row'>



<div class="card dis-non-crd-dt" id='suc-send-dis-1' style="">
 <div class='suc_ret_dt'><i class="fad fa-tasks"></i></div>
  <div class="card-body">
    <h3 class="card-title">Manage API Success</h3>
    <p class="card-text">Successfully handle Manage Api Request is</p>
  
  <div class="rate-wrt_dt"><h2><span id='suc-rate-of-api-1' class='lds_set_data'>0
</span> <sub>request</sub></h2></div>
  </div>
</div>




<div class="card dis-non-crd-dt" id='suc-send-dis-2' style="margin-left: auto;">
 <div class='suc_ret_dt'><i class="fad fa-paper-plane"></i></div>
  <div class="card-body">
    <h3 class="card-title">Sending API Success</h3>
    <p class="card-text">Successfully handle Send Api Request is</p>
    <div class="rate-wrt_dt"><h2><span id='suc-rate-of-api-2' class='lds_set_data'>0</span> <sub>request</sub></h2></div>
  
  </div>
</div>


</div>

</div>

<div class="head-of-inn-con">
<span class="nm-auta-con">API Template</span>
</div>


<div id='temp_to_res' class='row lds_set_data'></div>







<div class="head-cons-desg row">
  
  <div class="head-of-inn-con">
<span class="nm-auta-con">Sending History By API</span>
</div>


<div class="wrapper">
      <div class="search-input">
        <a href="" target="_blank" hidden></a>
        <input type="text" placeholder="Type to search..">
        <div class="autocom-box">
          <!-- here list are inserted from javascript -->
        </div>
        <div class="icon"><img src="https://res.cloudinary.com/heptera/image/upload/v1629699999/api/east_black_24dp_iuvk4s.svg"></div>
      </div>
    </div>

</div>

<div id='send_api_history' class='row lds_set_data'>


<div class="not-fd-temp-api-data"> <i class="fad fa-acorn" aria-hidden="true" style=" font-size: 90px; color: #b50a67; "></i> <div class="txt-data-nt-fd"> Not found any template data for API connect. </div> </div>


</div>


</div>









</div>

</div>

<style type="text/css">

.modal-header h2{

  color: black;
}
.content p{

color: #000000ab;
    font-weight: 500;

}

a.crt-api-btn-fin {
    background-color: #3368fa;
    color: white;
    padding: 10px;
    font-size: 15px;
    border-radius: 3px;

  }

  .cont-of-res-api-tok {
    border: 1px solid #a59f9f !important;
    border-radius: 5px;
    color: #777373;
    width: 70%;
  }

  input.hold-token-ip {
    height: 40px;
    border: none;
    border-radius: 5px;
    width: 90%;
    padding: 10px;
  }
  input.hold-token-ip:focus{

  }

  .copy-clip-tok {
    font-size: 20px;
    display: inline-block;
    width: 10%;
  }
  .cont-of-res-api-tok{
    margin: auto;
  }


  .del-send-api-temp {
    text-align: center;
    padding: 10px 0px;
    font-weight: 600;
    color: midnightblue;

  }

  i.fad.fa-acorn {
    font-size: 90px;
    color: #b50a67;
  }

  .txt-data-nt-fd {
    padding: 20px 0px;
    color: black;
    font-weight: 600;

  }
</style>





<div class="modal" id="modal-mngc-api-data" tabindex="-1" role="dialog" aria-labelledby="..." aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Managment API Key</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
   <div class="content">
      <p>Management API Is used for manage contact of contact list. <b>show,delete,add</b> contact from contact list. get your api key and access account from your system. <a class='hrf-doc-lnk' href="">Documentation</a></p>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs" class="crt-api-btn-fin" id='mngc'>Generate Key</button>
      </div>
    </div>
  </div>
</div>


<style type="text/css">


::selection{
  color: #fff;
  background: #664AFF;
}


.wrapper .search-input {
    background: #fff;
    width: 100%;
    border-radius: 5px;
    position: relative;
    width: 400px;
  }

.search-input input {
    height: 40px;
    width: 100%;
    outline: none;
    border: none;
    border-radius: 5px;
    padding: 0 60px 0 20px;
    font-size: 12px;
    border-radius: 10px !important;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
  }
.search-input.active input{
  border-radius: 5px 5px 0 0;
}

.search-input .autocom-box {
    padding: 0;
    opacity: 0;
    pointer-events: none;
    max-height: 280px;
    overflow-y: auto;
  }

.search-input.active .autocom-box {
    padding: 10px 8px;
    opacity: 1;
    pointer-events: auto;
    position: absolute;
    z-index: 10000;
    width: 100%;
    background: white;
    margin-top: 10px;
    box-shadow: rgb(50 50 93 / 25%) 0px 2px 5px -1px, rgb(0 0 0 / 30%) 0px 1px 3px -1px;
    border-radius: 10px;
  }



.autocom-box li {
    list-style: none;
    padding: 8px 12px;
    display: none;
    width: 100%;
    cursor: default;
    border-radius: 3px;
    font-size: 12px;
  }

  .autocom-box li:hover{
    cursor: pointer;
  }
.search-input.active .autocom-box li{
  display: block;
}
.autocom-box li:hover{
  background: #efefef;
}

.search-input .icon {
    position: absolute;
    right: 0px;
    top: 0px;
    height: 40px;
    width: 55px;
    color: #644bff;
    cursor: pointer;
    padding: 7px;
    text-align: center;
    background: #2f1cbd26;
    border-radius: 10px;
  }

  span.spn-of-sug.tag-of-sug {
    background: #00800038;
    padding: 3px 10px;
    margin-right: 10px;
    border-radius: 5px;
    color: green;
  }

</style>





<div class="modal" id="modal-send-api-data" tabindex="-1" role="dialog" aria-labelledby="..." aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header" style="
    border-bottom: 0px;
">
        <h5 class="modal-title new-crt-head" id="exampleModalLongTitle" style="
    color: black;
    font-size: 15px;
">Sending API Key</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-x-circle" viewBox="0 0 16 16">
  <path d="M8 15A7 7 0 1 1 8 1a7 7 0 0 1 0 14zm0 1A8 8 0 1 0 8 0a8 8 0 0 0 0 16z"></path>
  <path d="M4.646 4.646a.5.5 0 0 1 .708 0L8 7.293l2.646-2.647a.5.5 0 0 1 .708.708L8.707 8l2.647 2.646a.5.5 0 0 1-.708.708L8 8.707l-2.646 2.647a.5.5 0 0 1-.708-.708L7.293 8 4.646 5.354a.5.5 0 0 1 0-.708z"></path>
</svg>
        </button>
      </div>
      <div class="modal-body">
    
   <div class="content">
       <p>Sending API Is used to get send automayion of your system. like <b>OTP,transactonal message or create campign</b> from your automated system. for help read full <a class='hrf-doc-lnk' href="">Documentation</a></p>
    </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary btn-blck-non-fcs" data-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary btn-blck-in-auta-fcs"  id='send' >Generate Key</button>
      </div>
    </div>
  </div>
</div>













  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://res.cloudinary.com/dbkkxj00u/raw/upload/v1596968214/dashboard-js/bootstrap.bundle.min_up9k63.js"></script>
  
  <!--   Optional JS   -->
  
  <!--   Argon JS   -->
  <script src="js/suggestions.js"></script>
    <script src="js/script.js"></script>
  
  

  
</body>


<script type="text/javascript">

token_data={};

url_main='<?php echo $url_main;?>';

id='<?php echo $id;?>';

main_url_of_page="http://heptera.me/dash/main/api/api_temp/";


$(document).ready(function(){


$('[data-toggle="tooltip"]').tooltip();

init_api_data(id,function(){




});


init_temp_data(id);


setTimeout(function(){ init_send_api_hist_data(); }, 2000);


set_loader();

});


$(document).on("click","#trg_of_src_lst_dt",function(){


init_send_api_hist_data("search");

});


$(document).on("click",".cls-cop-handl",function(){

copyToClipboard($(this).attr('cop-id'));


console.log($(this).attr('cop-id'));
});

$(document).on("click",".crt-api-btn-fin",function(){

console.log("ravi");

var tp_con=$(this).attr('id');

$.post( "https://api.<?php echo $url_main;?>/api/add/"+tp_con+"/"+id, function( data ) {
  
  console.log(data);
   
if(tp_con=='mngc'){
  tp_con=1;
}else{
  tp_con=2;
}


append_act_in_mdl(tp_con,data);

})

});


$(document).on("click",".del-send-api-temp",function(){

del_temp_name=$(this).attr("del-id");



$.ajax({
  type: "POST",
  url: "./ajaxfile/del_temp_api_data.php",
  data:{temp_id:del_temp_name}
  
}).done(function(response1) {

init_temp_data(id);


});



});


const buttons = document.querySelectorAll('.trigger[data-modal-trigger]');

for(let button of buttons) {
  modalEvent(button);
}


function copyToClipboard(id) {
  var copyText = document.getElementById("cop-con-"+id);
  copyText.select();
  copyText.setSelectionRange(0, 99999)
  document.execCommand("copy");
  
 
}



function append_act_in_mdl(type,token){


$("#acc-token-handl-"+type).html("<div class='cont-of-res-api-tok'><input class='hold-token-ip' readonly='readonly' value="+token+" id='cop-con-"+type+"' ><div class='copy-clip-tok cls-cop-handl' cop-id='"+type+"'  ><i class='fal fa-copy' aria-hidden='true'></i></div></div>");

}



function init_api_data(id){

console.log(id);
$.get( "https://api.<?php echo $url_main;?>/api/all/"+id, function( data ) {
  

$("#suc-rate-of-api-1").html('0');
$("#suc-rate-of-api-2").html('0');


if(data.length>0){


	$(".suc_api-hand-rat-fl-bx").css('display','block');



  for (var i = 0; i < data.length; i++) {
    console.log(data[i].type);



    $("#suc-send-dis-"+data[i].type).css('display','block');

token_data["token"+data[i].type]=data[i].token;
   
   $("#suc-rate-of-api-"+data[i].type).html(data[i].req);

append_act_in_mdl(data[i].type,data[i].token);


  };


}else{





}

});




}


function init_temp_data(id){





$("#temp_to_res").empty();

$("#temp_to_res").html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");

$.ajax({
  type: "GET",
  url: "./ajaxfile/get_api_temp_data.php"
  
}).done(function(response1) {


  console.log(response1);

if(response1==0){


$("#temp_to_res").html("<div class='not-fd-temp-api-data'> <img src='https://res.cloudinary.com/heptera/image/upload/v1611119685/api/undraw_building_websites_i78t_tuy3cz.svg' style=' height: 200px; '> <div class='txt-data-nt-fd'> Not found any template data for API connect. </div> </div>");


}else{



temp_json_data=JSON.parse(response1);

$("#temp_to_res").html("");


for (var i = 0; i < temp_json_data.length; i++) {
  


temp_thumb(temp_json_data[i].temp_id);

};

   
   }
    
   
});




}



function temp_thumb(temp_id){

  


var str_for_temp_res="<div  class='' style='padding-left:0px;padding-right:0px;margin:auto;'><div class='temp_con'><img class='temp_img_con' data-toggle='modal' data-target='#temp_review_con' src='https://scr.auftera.com/scr-api/?url=https://dev.auftera.com/dev/api_temp/"+temp_id+".php&amp;width=700&amp;height=800'  width='200' height='250' id='img-of-temp' /><div class='cont-of-res-api-tok' style='width:100%;'><input class='hold-token-ip' readonly='readonly' value='"+temp_id+"' style='width:170px;' id='cop-con-"+temp_id+"'><div class='copy-clip-tok cls-cop-handl' style='width:30px;' cop-id='"+temp_id+"'><i class='fal fa-copy' aria-hidden='true'></i></div></div><div class='del-send-api-temp' del-id='"+temp_id+"'>Delete <i class='fal fa-trash-restore'></i></div></div></div>";

$("#temp_to_res").append(str_for_temp_res);



}










function init_send_api_hist_data(src_name){

src_data=[];



$("#send_api_history").html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");

if(src_name=="search"){

src_data[0]=$("#src_fld_sel").children("span").attr('id');
src_data[1]=$("#src_fld_val").val();

}

if(src_data[0]=='all'){

src_data=[];

}

src_data=JSON.stringify(src_data);



console.log(src_data);


$.ajax({
  type: "POST",
  url: "./ajaxfile/get_send_table_data.php",
  data:{token:token_data['token2'],src_data:src_data}  
}).done(function(response1) {


console.log(response1);
if(response1==0){


}else{

  console.log(response1);

data_arr=JSON.parse(response1);

set_email_send_data(data_arr);

}
    
   
});




}


function set_email_send_data(data_arr){
console.log(data_arr);




if(data_arr.length>0){
str_of_app="<table id='data-tbl-name'> <thead> <tr> <th>List Name</th> <th>Email</th> <th>Content Info</th> <th>Tag</th> <th>Status</th> </tr> <thead> <tbody>";

for (var i = 0; i < data_arr.length; i++) {

str_of_app+="<tr> <td>"+data_arr[i]['lst_name']+"</td> <td>"+data_arr[i]['email']+"</td> <td>"+data_arr[i]['content_dt']+"</td><td>"+data_arr[i]['tag']+"</td> <td>1</td>  </tr>";

};


str_of_app+="</tbody><table/>";
}else{



str_of_app='<div class="not-fd-temp-api-data"> <img src="https://res.cloudinary.com/heptera/image/upload/v1611120241/api/undraw_to_do_xvvc_vuiyex.svg" style=" height: 200px; "> <div class="txt-data-nt-fd"> You are not send email using sycista API plateform</div> </div>';



}

$("#send_api_history").html(str_of_app);

console.log(str_of_app);


}



function set_loader(){

$(".lds_set_data").html("<div class='lds-ring lds-color'  style=''><div></div><div></div><div></div><div></div></div>");

}


$(".default_option").click(function(){
  $(".dropdown-sel ul").addClass("active");
});

$(".dropdown-sel ul li").click(function(){
  var text = $(this).html();
  $(".default_option").html(text+"<i class='fad fa-chevron-down'></i>");
  $(".dropdown-sel ul").removeClass("active");
});




$(document).click(function() {
   


$(".search-input").removeClass('active');


});

$(".search-input").click(function(event) {
    add_act (this);

    event.stopPropagation();
});


</script>



</html>



