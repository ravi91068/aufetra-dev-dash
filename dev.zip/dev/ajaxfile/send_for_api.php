<?php
session_start();

$id=$_POST['id'];
require("../confige/heptera_api_conn.php");



function getInbetweenStrings($start, $end, $str){
    $matches = array();
    $regex = "/$start([a-zA-Z0-9_]*)$end/";
    preg_match_all($regex, $str, $matches);
    return $matches[1];
}




function cors() {

    // Allow from any origin
    if (isset($_SERVER['HTTP_ORIGIN'])) {
        // Decide if the origin in $_SERVER['HTTP_ORIGIN'] is one
        // you want to allow, and if so:
        header("Access-Control-Allow-Origin: {$_SERVER['HTTP_ORIGIN']}");
        header('Access-Control-Allow-Credentials: true');
        header('Access-Control-Max-Age: 86400');    // cache for 1 day
    }

    // Access-Control headers are received during OPTIONS requests
    if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
            // may also be using PUT, PATCH, HEAD etc
            header("Access-Control-Allow-Methods: GET, POST, OPTIONS");

        if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
            header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");

        exit(0);
    }

    
}

cors();



$get_temp_id=$_POST['temp_id'];

echo $get_temp_id;
$html = file_get_contents("https://template.sycista.com/template/crt-template/crtedtemp/".$get_temp_id.".html") or die("Unable to open file!");

$str_arr = getInbetweenStrings(':', ':', $html);


$str_arr=array_unique($str_arr);

foreach ($str_arr as $key => $value) {


$html=str_replace(":".$value.":","<?php echo \$_GET['".$value."'];?>",$html);


}

$camp_name=$id."^".strtotime("now");

$camp_save_dt_name_db=base64_encode($camp_name."#".$get_temp_id);

$camp_save_dt_name=$camp_save_dt_name_db.".php";

$myfile = fopen("../api_temp/".$camp_save_dt_name, "w") or die("Unable to open file!");
$txt = $html;

$open_res_img_tag="<img src='http://ec2-3-12-107-213.us-east-2.compute.amazonaws.com/test/api/open_data_of_mail_act.php?lst_name=<?php echo \$_GET['lst_name'];?>&camp_name=".$camp_name."&con_id=<?php echo \$_GET['con_id'];?>'>";

fwrite($myfile, $open_res_img_tag);

fwrite($myfile, $txt);
fclose($myfile);



$insrt_data_int_api_temp_tbl="insert into `heptera-api-temp` (usr_id,temp_id) value ('$id','$camp_save_dt_name_db')";



if($heptera_api_conn->query($insrt_data_int_api_temp_tbl)==TRUE){

        echo 1;
}else{


	        echo 0;
}


?>

