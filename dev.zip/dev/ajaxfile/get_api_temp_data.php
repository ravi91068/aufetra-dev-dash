<?php


session_start();

$id=$_SESSION['id'];


require("../confige/heptera_api_conn.php");


if(isset($id)){

$temp_data=array();

$sel_temp_data="select * from `heptera-api-temp` where usr_id='$id'";

$result_temp=$heptera_api_conn->query($sel_temp_data);


if ($result_temp->num_rows > 0) {
  // output data of each row
  while($row = $result_temp->fetch_assoc()) {
    

array_push($temp_data, $row);

  }


  echo json_encode($temp_data);
} else {
  echo 0;
}




}


?>